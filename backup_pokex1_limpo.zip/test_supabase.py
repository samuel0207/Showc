import os
from supabase import create_client

url = "https://ayfbuxpttvsjhqfebrvt.supabase.co"
key = "sb_secret_Enqh1weY7RK21TPsKIgMuw_DFf9KDpD"
try:
    print("Conectando ao Supabase com a nova chave...")
    supabase = create_client(url, key)
    res = supabase.table('users').select('*').limit(1).execute()
    print("SELECT:", res)
    # Testar insert para ver se bypassa RLS
    test_user = {'username': 'test_rls', 'password': '123', 'score': 1000}
    res_insert = supabase.table('users').upsert(test_user).execute()
    print("INSERT:", res_insert)
except Exception as e:
    print("ERRO:", e)
